// Laba2.cpp: определяет точку входа для консольного приложения.
//
//Реализовать класс Account представляющий собой банковский счет.
//В классе должны быть 4 поля: ФИО, номер счета, процент начисления, сумма в рублях.
//Открытие счета выполняется операцией инициализации.
//Необходимо выполнять следующий операции: сменить владельца счета,снять некоторую сумму денег со счета,
//положить деньги на счет, начислить проценты, перевести сумму в доллары, евро.

#include "stdafx.h"
#include <iostream>
#include <string>
#include <sstream>

using namespace std;



class Account
{ 
public:

	typedef struct //сведения о клиенте 
	{
		char Name[80];// ФИО клиента
		unsigned int AccNum;// номер счета
		double Percent;// проценты
		double Money;//сумма в рублях 
	}TAccount;



	//создание нового аккаунта
	void OpenAccount(TAccount *Acc)
	{
		cout << "Enter data for new account!\n";
		cout << "Name: ";     cin >> Acc->Name;
		cout << "Account number: ";    cin >> Acc->AccNum;
		cout << "Percent: ";	cin >> Acc->Percent;
		cout << "Sum in Rub: ";		 cin >> Acc->Money;
	}

	//сменить владельца счета
	void ChangeOwner(TAccount *Acc)
	{
		cout << "Enter new owner: ";	 cin >> Acc->Name;
	}

	//снятие денег
	void MinusMoney(TAccount *Acc)
	{
		unsigned int sum;
		cout << "enter sum: "; cin >> sum;
		Acc->Money = Acc->Money + sum;
	}

	//добавление денег
	void PlusMoney(TAccount *Acc)
	{
		unsigned int sum;
		cout << "enter sum: "; cin >> sum;
		Acc->Money = Acc->Money - sum;
	}

	//перевод в евро
	void TransferMoneyInEuro(TAccount *Acc)
	{		
		Acc->Money = Acc->Money / 70;
	}

	//перевод в доллары
	void TransferMoneyInDollar(TAccount *Acc)
	{
		Acc->Money = Acc->Money / 60;
	}

	void AddPercent()
	{

	}
};



void Task()
{
	

}


/*Функция продолжения действий*/
bool Answ() {
	int answ;
	cout << "------------" << endl;
	cout << "Хотите продолжить действия?" << endl;
	cout << "1. Да" << endl;
	cout << "2. Нет" << endl;
	cin >> answ;
	switch (answ)
	{
	case 1: {
		return true;
	}
	case 2: {
		return false;
	}
	default: {
		cout << "Ошибка. Введите корректный номер пункта меню." << endl;
		Answ();
		break;
	}
	}

}

void Repeat() {
	while (Answ()) {
		Task();
	}
}

int main()
{
	Account TAccaunt ;
	setlocale(LC_ALL, "Russian");

	Task();
	Repeat();
	system("pause");
	return 0;
}